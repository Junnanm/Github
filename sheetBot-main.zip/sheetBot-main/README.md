# sheetBot
A Discord bot for TETR.IO that pulls up more advanced statistics and analytics than Tetra Channel provides.

## Branch Contributors
<b>Takathedinosaur, dan63047, TossedBloom</b>

## Other Notable Contributions
<h3>pncl and iLumine</h3>
- Largely responsible for the creation of the playstyle stats, with a bit of my guidance thrown in.
<h3>RKPLol</h3>
- For showing me the win probability formula and helping with its implementation into the bot.
<h3>Zepheniah and Dragonboy</h3>
- Helping with the creation of Garbage Effi.
<h3>Windcatcher</h3>
- Inspiration for making this bot in the first place, as well as being the first to expose me to formulas like DS/Piece.
<h3>Haikai</h3>
- Giving graphic design advice for some of the charts.
<h3>Takathedinosaur</h3>
- Making the excellent TakaTheBot and keeping me motivated to keep going. Also helped write one of the branches for this GitHub!
<h3>dan63047</h3>
- Helped write one of the branches for this GitHub, as well as assisting with beta testing.
<h3>Firenight Souls, LHayabuza, Sedaji, cmdingo</h3>
- Beta testing for this build of the bot.
<h3>Tronsi</h3>
- Some help with code and implementation in the very early stages.
<h3>NotARock and Ultranooby</h3>
- Helping to teach me some proper statistical analysis, helping to make the Est. TR formula possible.
<h3>swng and CCRed95</h3>
- Making some other statistical analysis programs that are super worth checking out. Also are both incredibly cool dudes.
